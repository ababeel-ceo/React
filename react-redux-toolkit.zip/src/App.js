
import DataEntry from './Components/DataEntry';
import ShowData from './Components/ShowData';

function App() {
  return (
    <div className="App">
      mbkjdslkjflkj
      <h2>Hello World</h2>
        <ShowData/>
        <DataEntry/>
    </div>
  );
}

export default App;
