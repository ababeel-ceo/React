import { createSlice } from "@reduxjs/toolkit";

export const globalState = createSlice({
  name: 'studentstore',
  initialState: {
    name: 'Abdulla B',
    age: '23', 
    marks: '100%',
  },
  reducers: {
    setStudentValue: (state, action) => {
      return { ...state, ...action.payload };
    }
  }
});

export const { setStudentValue } = globalState.actions;
export default globalState.reducer;