
import { useSelector } from "react-redux";

const ShowData = () => {
    const studentData = useSelector(state =>state.studentstore)
    return ( 
        <div>
            <p>Student Name : {studentData.name}</p>
            <p>Student Age : {studentData.age}</p>
            <p>Staudent Mark : {studentData.marks}</p>
        </div>
     );
}
 
export default ShowData;