import { useDispatch } from "react-redux";
import { setStudentValue } from "../Store/globalStore";
import { useState } from "react";

const DataEntry = () => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [mark, setMark] = useState(''); 
  const dispatch = useDispatch();


  const handleClick = () => {
    console.log("------",name,"----",age,"-----",mark)
    dispatch(setStudentValue({
      name: name,
      age: age,
      marks: mark
    }));
  }

  return ( 
    <div>
      <label htmlFor="name">Name: </label>
      <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} /><br /><br />

      <label htmlFor="age">Age: </label>
      <input type="text" id="age" value={age} onChange={(e) => setAge(e.target.value)} /><br /><br />

      <label htmlFor="mark">Mark: </label>
      <input type="text" id="mark" value={mark} onChange={(e) => setMark(e.target.value)} /><br /><br />

      <button onClick={handleClick}>Submit</button>
    </div>
  );
}

export default DataEntry;
